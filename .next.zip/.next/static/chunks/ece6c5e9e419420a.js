__turbopack_load_page_chunks__("/_error", [
  "static/chunks/17722e3ac4e00587.js",
  "static/chunks/3afd97753a48f4e9.js",
  "static/chunks/turbopack-c7e43a0257ec330f.js"
])
