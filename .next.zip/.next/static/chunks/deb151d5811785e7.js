__turbopack_load_page_chunks__("/_app", [
  "static/chunks/e60ef129113f6e24.js",
  "static/chunks/3afd97753a48f4e9.js",
  "static/chunks/turbopack-e73369f607865231.js"
])
