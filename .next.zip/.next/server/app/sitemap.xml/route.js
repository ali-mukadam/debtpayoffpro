var R=require("../../chunks/[turbopack]_runtime.js")("server/app/sitemap.xml/route.js")
R.c("server/chunks/[root-of-the-server]__e216d455._.js")
R.c("server/chunks/node_modules_next_dist_77fd8386._.js")
R.c("server/chunks/node_modules_next_dist_03a3c8f9._.js")
R.c("server/chunks/[root-of-the-server]__69acd73d._.js")
R.m(29262)
R.m(37438)
module.exports=R.m(37438).exports
