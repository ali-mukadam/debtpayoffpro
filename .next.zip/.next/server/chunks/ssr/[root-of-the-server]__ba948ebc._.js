module.exports=[6029,a=>{a.v({className:"inter_7b064e0d-module__MOT0tq__className",variable:"inter_7b064e0d-module__MOT0tq__variable"})},72123,(a,b,c)=>{let{createClientModuleProxy:d}=a.r(11857);a.n(d("[project]/node_modules/next/dist/client/script.js <module evaluation>"))},44536,(a,b,c)=>{let{createClientModuleProxy:d}=a.r(11857);a.n(d("[project]/node_modules/next/dist/client/script.js"))},11153,a=>{"use strict";a.i(72123);var b=a.i(44536);a.n(b)},71618,(a,b,c)=>{b.exports=a.r(11153)},27572,a=>{"use strict";a.s(["default",()=>h,"metadata",()=>g,"viewport",()=>f],27572);var b=a.i(7997),c=a.i(6029);let d={className:c.default.className,style:{fontFamily:"'Inter', 'Inter Fallback'",fontStyle:"normal"}};null!=c.default.variable&&(d.variable=c.default.variable);var e=a.i(71618);let f={width:"device-width",initialScale:1},g={title:"Free Credit Card Debt Payoff Calculator 2025 | DebtPayoffPro",description:"Free Credit-Card Debt Payoff Calculator. Compare Avalanche vs Snowball methods, Monthly payments and Interest Savings. Start your Debt Free journey today.",keywords:["debt payoff calculator","credit card calculator","debt avalanche calculator","debt snowball calculator","pay off debt faster","debt elimination calculator","credit card payoff calculator","debt consolidation calculator","personal loan calculator","debt free calculator","financial calculator","debt payoff strategies","avalanche method","snowball method","debt payoff plan","interest calculator","debt reduction calculator"],authors:[{name:"DebtPayoffPro Team"}],creator:"DebtPayoffPro",publisher:"DebtPayoffPro",formatDetection:{email:!1,address:!1,telephone:!1},metadataBase:new URL("https://debtpayoffpro.com"),alternates:{canonical:"https://debtpayoffpro.com"},openGraph:{title:"Free Credit Card Debt Payoff Calculator 2025 | DebtPayoffPro",description:"Free Credit-Card Debt Payoff Calculator. Compare Avalanche vs Snowball methods, Monthly payments and Interest Savings. Start your Debt Free journey today.",url:"https://debtpayoffpro.com",siteName:"DebtPayoffPro",images:[{url:"/OGimage.png",width:1200,height:630,alt:"DebtPayoffPro - Free Debt Payoff Calculator"}],locale:"en_US",type:"website"},robots:{index:!0,follow:!0,googleBot:{index:!0,follow:!0,"max-video-preview":-1,"max-image-preview":"large","max-snippet":-1}},category:"finance",classification:"Financial Calculator",icons:{icon:"/logo.png",shortcut:"/logo.png",apple:"/logo.png"}};function h({children:a}){return(0,b.jsxs)("html",{lang:"en",children:[(0,b.jsxs)("head",{children:[(0,b.jsx)("style",{dangerouslySetInnerHTML:{__html:`
            /* Critical above-the-fold styles */
            .hero-container {
              min-height: 100vh;
              background: #ffffff;
              display: flex;
              align-items: center;
              justify-content: center;
            }
            
            .hero-title {
              font-size: 2.5rem;
              font-weight: bold;
              color: #00509E;
              line-height: 1.2;
              margin-bottom: 1rem;
              font-family: var(--font-inter), Arial, sans-serif;
            }
            
            .hero-subtitle {
              font-size: 1.25rem;
              color: #374151;
              margin-bottom: 2rem;
              font-family: var(--font-inter), Arial, sans-serif;
            }
            
            .form-container {
              background: white;
              border-radius: 0.5rem;
              box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
              padding: 2rem;
            }
            
            /* Prevent layout shift */
            .main-container {
              min-height: 100vh;
              background: #ffffff;
            }
            
            /* Critical header styles */
            .header-container {
              background: white;
              box-shadow: 0 1px 3px 0 rgba(0, 0, 0, 0.1);
              border-bottom: 1px solid #e5e7eb;
            }
            
            /* Critical text styles for LCP element */
            .text-4xl {
              font-size: 2.25rem;
              line-height: 2.5rem;
            }
            
            .text-5xl {
              font-size: 3rem;
              line-height: 1;
            }
            
            .font-bold {
              font-weight: 700;
            }
            
            .text-xl {
              font-size: 1.25rem;
              line-height: 1.75rem;
            }
            
            .text-gray-600 {
              color: #4b5563;
            }
            
            .mb-4 {
              margin-bottom: 1rem;
            }
            
            .mb-8 {
              margin-bottom: 2rem;
            }
            
            .max-w-3xl {
              max-width: 48rem;
            }
            
            .mx-auto {
              margin-left: auto;
              margin-right: auto;
            }
            
            .text-center {
              text-align: center;
            }
            
            /* Critical container styles */
            .container {
              width: 100%;
              margin-left: auto;
              margin-right: auto;
              padding-left: 1rem;
              padding-right: 1rem;
            }
            
            @media (min-width: 640px) {
              .container {
                max-width: 640px;
              }
            }
            
            @media (min-width: 768px) {
              .container {
                max-width: 768px;
              }
            }
            
            @media (min-width: 1024px) {
              .container {
                max-width: 1024px;
              }
            }
            
            @media (min-width: 1280px) {
              .container {
                max-width: 1280px;
              }
            }
            
            @media (min-width: 1536px) {
              .container {
                max-width: 1536px;
              }
            }
          `}}),(0,b.jsx)("link",{rel:"preconnect",href:"https://fonts.googleapis.com"}),(0,b.jsx)("link",{rel:"preconnect",href:"https://fonts.gstatic.com",crossOrigin:""}),(0,b.jsx)("link",{rel:"preload",href:"https://fonts.gstatic.com/s/inter/v12/UcCO3FwrK3iLTeHuS_fvQtMwCp50KnMw2boKoduKmMEVuLyfAZ9hiA.woff2",as:"font",type:"font/woff2",crossOrigin:""}),(0,b.jsx)("link",{rel:"preconnect",href:"https://www.googletagmanager.com"}),(0,b.jsx)("link",{rel:"dns-prefetch",href:"https://www.google-analytics.com"})]}),(0,b.jsxs)("body",{className:`${d.variable} antialiased`,children:[(0,b.jsx)(e.default,{src:"https://www.googletagmanager.com/gtag/js?id=G-K51GGR26LE",strategy:"afterInteractive"}),(0,b.jsx)(e.default,{id:"google-analytics",strategy:"afterInteractive",children:`
            window.dataLayer = window.dataLayer || [];
            function gtag(){dataLayer.push(arguments);}
            gtag('js', new Date());
            gtag('config', 'G-K51GGR26LE');
          `}),(0,b.jsx)(e.default,{id:"structured-data",type:"application/ld+json",strategy:"afterInteractive",children:JSON.stringify([{"@context":"https://schema.org","@type":"WebApplication",name:"DebtPayoffPro Calculator",description:"Free Credit Card Debt Payoff Calculator. Compare Avalanche vs Snowball methods, Monthly payments and Interest Savings. Start your Debt Free journey today.",url:"https://debtpayoffpro.com",applicationCategory:"FinanceApplication",operatingSystem:"Web Browser",browserRequirements:"Requires JavaScript",offers:{"@type":"Offer",price:"0",priceCurrency:"USD",description:"Free to use"},featureList:["Avalanche Method Calculator","Snowball Method Calculator","Interest Savings Calculator","Monthly Payment Calculator","Debt Comparison Tools","Payoff Timeline Visualization"],screenshot:"https://debtpayoffpro.com/OGimage.png",author:{"@type":"Organization",name:"DebtPayoffPro"},publisher:{"@type":"Organization",name:"DebtPayoffPro",url:"https://debtpayoffpro.com",logo:{"@type":"ImageObject",url:"https://debtpayoffpro.com/logo.png"}}},{"@context":"https://schema.org","@type":"Organization",name:"DebtPayoffPro",url:"https://debtpayoffpro.com",logo:"https://debtpayoffpro.com/logo.png",description:"Free debt payoff calculator tools and financial planning resources",foundingDate:"2025",sameAs:["https://debtpayoffpro.com"]}])}),a]})]})}}];

//# sourceMappingURL=%5Broot-of-the-server%5D__ba948ebc._.js.map