globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": [
      "static/chunks/e60ef129113f6e24.js",
      "static/chunks/3afd97753a48f4e9.js",
      "static/chunks/turbopack-e73369f607865231.js"
    ],
    "/_error": [
      "static/chunks/17722e3ac4e00587.js",
      "static/chunks/3afd97753a48f4e9.js",
      "static/chunks/turbopack-c7e43a0257ec330f.js"
    ]
  },
  "devFiles": [],
  "ampDevFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/b86ee4016e9cfcf5.js",
    "static/chunks/f481cfa305f447cb.js",
    "static/chunks/c1915865246da9ba.js",
    "static/chunks/turbopack-cbdfb0eb863890a5.js"
  ],
  "ampFirstPages": []
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
,"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js",

];